
// ------------------------------------------------------------------
// PLUTO PROTOCOL: FIREBASE REMOVED
// ------------------------------------------------------------------

// This file is now a stub. All cloud functionality has been stripped.
// The app now runs in a purely local environment using localStorage.

export const isConfigured = false;

export const db = null;
export const auth = null;
export const analytics = null;
